INSERT INTO employee(name, last_name, email, phone, active) values ('Gustavo','Ponce','test@test.com','1234567890',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Bob','Marley','one@love.com','6483748590',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('David','Gilmour','high@hopes.com','7648909831',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('John','Lennon','standby@me.com','7689485620',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Ozzy','Osbourne','children@grave.com','6483748590',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('Jimmy','Page','stairway@heaven.com','7648909831',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Jimi','Hendrix','purple@haze.com','8754091236',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('Sex','Pistols','save@queen.com','6729098761',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Jim','Morrison','riders@storm.com','8754091236',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('Richard','Blackmore','highway@star.com','8754091236',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Jay','Kay','cosmic@girl.com','0926389871',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('David','Bowie','heroes@oneday.com','4338490981',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Bob','Dylan','knocking@doors.com','4338490981',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('Manu','Chao','mala@vida.com','8923098753',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('The','Specials','ghost@thown.com','7590498573',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Jymmy','Cliff','see@clearly.com','4338490981',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('The','Temptations','my@girl.com','7639864096',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Simon','Garfunkel','mr@robinson.com','8750987531',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('catch','22','takes@sometime.com','7098653427',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Janis','Joplin','cry@baby.com','6739087641',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('Lou','Red','wild@side.com','6789045678',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Iggy','Pop','the@passenger.com','6934980751',true);
INSERT INTO employee(name, last_name, email, phone, active) values ('Dead','Kennedys','holiday@cambodia.com','2389096457',false);
INSERT INTO employee(name, last_name, email, phone, active) values ('The','Cure','dont@cry.com','8749340987',false);

INSERT INTO ROLE values(1, 'ADMIN');



